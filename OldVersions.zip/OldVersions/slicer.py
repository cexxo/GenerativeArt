from ctypes.wintypes import RGB
import image_slicer as sl
import random
from PIL import Image

#this function takes care on the conversion of images with a background which is white instead of transparent
def convertImage(path):                                                     #it accept a varible path that is the path to the image i'll work on
    img = Image.open(path)                                                  #i open the image according to the path that was given
    img = img.convert("RGBA")                                               #i convert the image in an image RGBA so that i can controll the
                                                                            # images levels
    datas = img.getdata()                                                   #i get the layer datas of the images, the quantity of red, blue
                                                                            # and yellow. it is expressed as (R,G,B)
    newData = []                                                            #i create an array so that i can store the new RGB's data
                                                                            
    for items in datas:                                                     #i iterate the components of each RGB tuples
        if items[0] == 255 and items[1] == 255 and items[2] == 255:         #if i found that each component of a tuple is 255, i've found the
            newData.append((255, 255, 255, 0))                              #white color, so i convert it into a transparent component
        else:                                                               
            newData.append(items)                                           #othrwise i leave the tuple without modifications
                                                                            
    img.putdata(newData)                                                    #i substitute the old data of the pictures witht the new ones
    img.save(path)                                                          #i save the image in the same path as the old one. i'm overwriting it


def main():
    hair = []                                                               #these are the array that will contain our parts of the NFT, hair,
    mouth = []                                                              #mouth and eyes
    eyes = []                                                               #i use them mainly to have a size to work with. we are not gonna
                                                                            #touch them.
    try:                                                                    #here we fill our array with the images we created, so that we can
        for i in range(1,7):                                                #access directly on them
            hair.append(open("NFT\hair\hair{}.png".format(int(i))))         #the try except block is here so that there should be no problems
            mouth.append(open("NFT\mouth\mouth{}.png".format(int(i))))      #with the file managment
            eyes.append(open("NFT\eyes\eyes{}.png".format(int(i))))
    except:
        print("problem with files...")                                      #a generic error for now, gonna be more specific on next versions
    #print(len(hair),len(mouth),len(eyes))                                  #check on the size of the arrays
    
    while(True):
        print("Input the numbers of NFTs you wanna produce: ")              #input on the number of NFTs to create, we don't want doubles in        
        s = int(input())                                                    #this program, otherwise they will not be unique.
        if(s <= len(hair)*len(mouth)*len(eyes)):                            #we must check that the input is less than all possible combinations
            break                                                           #if that's the case, we can go out of the loop.
    
    ##now we are gonna focus on the random generation part, this is just a first version of the code, it is gonna be modified soon :)
    
    for i in range(1,7):                                                    #this function has to be update so that the range changes in base
        convertImage("NFT\hair\hair{}.png".format(i))                       #of the number of element i have for each layer of my NFT.
        convertImage("NFT\mouth\mouth{}.png".format(i))                     #I call the convertImage function for each element, so that i'm
        convertImage("NFT\eyes\eyes{}.png".format(i))                       #always sure they are gona have transparent backgrounds.

    for k in range(s):                                                      #I iterate for the number of NFTs that the user choose.
        r_h = random.randint(1,6)                                           #I have 3 random numbers which are gonna give the number of the 
        r_m = random.randint(1,6)                                           #element i'm gonna use for each of the 3 layers
        r_e = random.randint(1,6)                                           #they have denominations according to the layer they refer to.

        f = Image.open("NFT\{}ace\{}ace.png".format("f","f"))               #I open the bease layer of my NFT, which is the face
        h = Image.open("NFT\hair\hair{}.png".format(r_h))                   #I hopen the r_h-th element of the hair layer
        e = Image.open("NFT\eyes\eyes{}.png".format(r_e))                   #I hopen the r_e-th element of the eyes layer
        m = Image.open("NFT\mouth\mouth{}.png".format(r_m))                 #I hopen the r_m-th element of the mouth layer  

        ##The paste function accepts 3 paramethers: the image to paste on our background image, the position (x,y coordinates) where the selected
        # image has to be pasted, the mask layer. I use the second image as mask layer so that i ensure that only the non trasparent part
        # is gonna be merged with our background. For more specifics read the pillow documentation.                                           
        f.paste(h,(0,0),h)                                                  #I merge together the face layer with the hair layer
        f.paste(e,(0,0),e)                                                  #I merge together the face layer with the eyes layer
        f.paste(m,(0,0),m)                                                  #I merge together the face layer with the mouth layer

        f.save("result{}.png".format(k+1),"PNG")                            #I save the result.

if __name__ == '__main__':
    main()

"""for i in range (len(a)):
            result.append(d[i])
        for i in range(len(a)):
            r = random.randint(1,3)
            if r == 1:
                result.append(a[i])
            elif r == 2:
                result.append(b[i])
            elif r == 3:
                result.append(c[i])
        cavolo = sl.join(result)
        cavolo.save("result{}.png".format(k))
        result.clear()"""