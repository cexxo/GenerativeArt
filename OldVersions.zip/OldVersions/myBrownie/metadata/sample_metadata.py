metadata_template = {
        "name": "",
        "description": "",
        "image": "",
        "attributes": [
                {"trait_type": "mask", "value": 0},
                {"trait_type": "clothes", "value": 0},
                {"trait_type": "ritual", "value": 0}
                ]
}
