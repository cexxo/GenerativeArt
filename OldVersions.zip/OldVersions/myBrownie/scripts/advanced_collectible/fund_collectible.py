from brownie import *

def fund_advanced_collectible(nft_contract):
    dev = accounts.add(config['wallets']['from_key'])
    link_token = interface.LinkTokenInterface(config['networks'][network.show_active]['link_token'])
    link_token.transfer(nft_contract, 1000000000, {"from": dev})

def main():
    advanced_collectible = AdvancedCollectible[len(AdvancedCollectible)-1]
    fund_advanced_collectible(advanced_collectible)

if __name__ == "__main__":
    main()
