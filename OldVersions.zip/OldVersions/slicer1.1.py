from ctypes.wintypes import RGB
import image_slicer as sl
import random
from PIL import Image

#this function takes care on the conversion of images with a background which is white instead of transparent
def convertImage(path):                                                     #it accept a varible path that is the path to the image i'll work on
    img = Image.open(path)                                                  #i open the image according to the path that was given
    img = img.convert("RGBA")                                               #i convert the image in an image RGBA so that i can controll the
                                                                            # images levels
    datas = img.getdata()                                                   #i get the layer datas of the images, the quantity of red, blue
                                                                            # and yellow. it is expressed as (R,G,B)
    newData = []                                                            #i create an array so that i can store the new RGB's data
                                                                            
    for items in datas:                                                     #i iterate the components of each RGB tuples
        if items[0] == 255 and items[1] == 255 and items[2] == 255:         #if i found that each component of a tuple is 255, i've found the
            newData.append((255, 255, 255, 0))                              #white color, so i convert it into a transparent component
        else:                                                               
            newData.append(items)                                           #othrwise i leave the tuple without modifications
                                                                            
    img.putdata(newData)                                                    #i substitute the old data of the pictures witht the new ones
    img.save(path)                                                          #i save the image in the same path as the old one. i'm overwriting it

#this function is a path cleaner function, which allows us to avoid unpleasent errors :)
def pathManipulation(s):                                                    #with this function i clean the paths in input.
    temp = ""                                                               #due to python's way of interpreting inputs, it is necessary to
    for i in range(len(s)):                                                 #remove the double \ from the paths, otherwise the program 
        if s[i] == "\\" and s[i+1] == "\\":                                 #doesn't work due to errors in finding the necessary files
            continue
        temp = temp + s[i]                                                  #it's a really simple algorith, it replaces \\ with \
    s = temp

def main():
    print("How many layers do you have?")                                   #Dialog to input how many layers our picture has
    nLayers = int(input())                                                  #input the number of layers
    print("How many elements has each layer?")                              #Dialog to input the numbers of element in each layer
    nElements = int(input())                                                #input the number of elements
    while(True):                                                            
        print("Input the numbers of NFTs you wanna produce: ")              #maxNFT is the variable where i'm gonna store the maximum value
        num_NFT = int(input())                                              #of NFTs i wanna produce
        maxNFT = nElements**nLayers                                         #num_NFT is the number the user gives in input. is the number
                                                                            #of NFTs the user wants to create.                                      
        if(num_NFT <= maxNFT):                                              #we must check that the input is less than all possible combinations
            break                                                           #so that i can have all the NFT without having repetition.
        else:
            print("number not acceptable... \n")                            #otherwise, ask again the user to input the number of NFTs he wants
            
    Layer = []                                                              #i create an array where i will store my layers
    paths = []                                                              #i create an array where i'll store the path of the i-th layer
    randoms = []                                                            #i'll memorize the random values of each layer here. this number
                                                                            #will determine which element of the layer we'll use.
    temp = ""
    print("Insert the path of the baseImage: ")                             #dialog for the input of the baseImage of our NFT
    base = input()                                                          #the actual input.                                                  #I clean he path of the image
    for i in range(nLayers):                                                #I iterate for each path i have to store
        print("Insert the path of the {}-th layer: ".format(i+1))           #simple dialog 
        paths.append(input())                                               #get the input and store it on the i-th element of the paths
    
    for i in range(num_NFT):                                                #this is the whole cycle that generates our NFTs
        for k in range(nLayers):                                            # generate the random numbers for choosing the element i want in
            randoms.append(random.randint(1,nElements))                     # my NFT.
        pathManipulation(base)
        Layer.append(base)                                                  #I add the base image to the Layers
        try:                                                                #here we fill our layer array so that we can use the final path
            for j in range(nLayers):                                        #to directly access to the elements of our NFT.
                temp = paths[j] + str(randoms[j]) + ".png"                  #i create the final path of the random element of the j-th layer
                pathManipulation(temp)                                      #i clean the path the user put in the command-line
                convertImage(temp)                                          #i convert the image so that each single picture has a transparent
                                                                            #background
                Layer.append(temp)                                          #that stores the path of the j-th element of the layer
                temp = ""                                                   #i clean the temporari path so that i can create a new one for the
                                                                            #next element of our NFT.
        except:
            print("problem with files...")                                  #a generic error for now, gonna be more specific on next versions
        
        ##The paste function accepts 3 paramethers: the image to paste on our background image, the position (x,y coordinates) where the selected
        # image has to be pasted, the mask layer. I use the second image as mask layer so that i ensure that only the non trasparent part
        # is gonna be merged with our background. For more specifics read the pillow documentation. 
        baseImage = Image.open(Layer[0])                                    #the baseImage is the image that is gonna give us the final result
        for k in range(1,nLayers+1):                                        #in layer 0 there should always be tha background image.
            temp = Image.open(Layer[k])                                     #i open the image of the k-th layer and store it in a temp variable.
            baseImage.paste(temp,(0,0),temp)                                #i'm gonna paste each of the layers to the baseImage so that in the
        baseImage.save("result{}.png".format(i+1),"PNG")                    #end i will have the complete NFT.
        randoms.clear()                                                     #I save the image as the i-th result of our production process.
        Layer.clear()                                                       #I clean the 2 arrayw where i store the definive paths and components.

if __name__ == '__main__':
    main()