from brownie import *
import time 

def get_breed(breed_number):
    switch = {0: 'PUG', 1:'SHIBA_INU', 2:'ST_BERNARD', 3:'KAKKA',4:'NUNZIA'}
    return switch[breed_number]

STATIC_SEED = 12345

def main():
    dev = accounts.add(config['wallets']['from_key'])
    advanced_collectible = AdvancedCollectible[len(AdvancedCollectible) - 1]
    transaction = advanced_collectible.createCollectible(STATIC_SEED,"None",{"from":dev,"gas_limit":2600000})
    transaction.wait(1)
    requestId = transaction.events['requestedCollectible']['requestId']
    token_id = advanced_collectible.requestIdToTokenId(requestId)
    time.sleep(60)
    breed = get_breed(advanced_collectible.tokenIdToBreed(token_id))
    print('Dog breed of token{} is {}'.format(token_id,breed))
    

if __name__ == "__main__":
    main()
