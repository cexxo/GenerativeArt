from brownie import AdvancedCollectible, accounts, network, config, interface
import time
def fund_advanced_collectible(nft_contract):
    dev = accounts.add(config['wallets']['from_key'])
    link_token = interface.LinkTokenInterface(config['networks'][network.show_active()]['link_token'])
    link_token.transfer(nft_contract, 1000000000000000000, {"from": dev})

STATIC_SEED = 123

def main():
    dev = accounts.add(config['wallets']['from_key'])
    print(network.show_active())
    publish_source = False
    advanced_collectible = AdvancedCollectible.deploy( config['networks'][network.show_active()]['vrf_coordinator'], config['networks'][network.show_active()]['link_token'],config['networks'][network.show_active()]['keyhash'],{"from": dev},publish_source=publish_source)
    fund_advanced_collectible(advanced_collectible)
    return(advanced_collectible)

    
if __name__ == "__main__":
    main()
