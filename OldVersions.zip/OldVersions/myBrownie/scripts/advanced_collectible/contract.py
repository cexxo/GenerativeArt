from brownie import *
from metadata import sample_metadata
from pathlib import Path
import os
import requests
import json
import time


def fund_advanced_collectible(nft_contract):                            #this function allows us to fund our contract
    dev = accounts.add(config['wallets']['from_key'])                   #i create a variable that stores our wallet
    link_token = interface.LinkTokenInterface(                          #i create a variable that will allow us to us tokens from our wallet
        config['networks'][network.show_active()]['link_token']         #the variable is configurated on our testnet newtwork
        )                                                               #so that we can spen our matic
    link_token.transfer(nft_contract,1000000000000000000,{"from": dev})   
                                                                        #i transfer the matic for our contract by specifing
                                                                        #the contract and the value in Wei i'll use.
                                                                        #the third paramter is the wallet i'll use for the 
                                                                        #transaction

def get_breed(breed_number):                                            #this fucntion allows us to give names to our NFTs, it returns the 
    switch = {                                                          #name of the type of NFT according to the number our NFT got from 
        0: 'PUG',                                                       #the random generation of the Id.
        1:'SHIBA_INU',                                                  #it has to be update to the 500 NFTs dictionary. 
        2:'ST_BERNARD',
        3:'KAKKA',
        4: 'NUNZIA'                                                  #The "index" order must follow the same as in the AdvancedCollectible.sol
        }                                                               #otherwise there might be a name that doesn't match the NFT itself.
    return switch[breed_number]                                         #returns the name of the NFT.

def write_metadata(number_of_tokens, nft_contract):                     #this function allows us to write the metadatas of our NFTs.
    for token_id in range(number_of_tokens):                            #for each token_id in all the tokens we minted:
        collectible_metadata = sample_metadata.metadata_template        #i create a variable that stores the metadata_template form the class
                                                                        #sample metadata.
        breed = get_breed(nft_contract.tokenIdToBreed(token_id))        #now i get the name of the NFT for the token_id i'm considering
        metadata_file_name = (                                          #the file has to be a file json, stored in the folder metadata/mumbai.
            "./metadata/mumbai/" +                                      #the final name is gonna me the token_id number, followed by -, the
            str(token_id) + "-" +                                       #name of the NFT and by the extension .json.
            breed +                                                     #all of this is gonna be stored in the variable called metadata_file_name
            ".json"                                                     #which we are gona use later.
            )                                                           
        if Path(metadata_file_name).exists():                           #if the metadaeta file has already been created
            print("{} alreafy found!".format(metadata_file_name))       #i notify tat it already exits.
        else:                                                           #otherwise
            print(                                                      #i notify that i'm creating the new metadata file
                "Creating Metadata File {}".format(metadata_file_name)  
                )                                                       
            collectible_metadata["name"]=get_breed(                     #the name field of our metadata.json file is gonna be given by the 
                nft_contract.tokenIdToBreed(token_id)                   #function defined earlier. this is applied to the specific token_id
                )                                                       #we are analyzing in this iteration
            collectible_metadata["description"]="An adorable {} pup".format(# the fiel description is gonna be a standard one (for now), and it's
                collectible_metadata["name"]                            #gonna include also the name found earlier.
                )                                                       
            image_to_upload = None                                      #the new variable that will contain the image to upload, for now None
            if os.getenv("UPLOAD_IPFS") == "true":                      #if the enviromental variable UPLOAD_IPFS is set to true
                image_path = "./img/{}.png".format(                     #then the image path points at the directory img and it's gonna get 
                    breed.lower().replace("_","-")                      #the image that has a name in the format NFT_name, and it's gonna replace
                    )                                                   #the _ with -
                image_to_upload = upload_to_ipfs(image_path)            #here i'm gonna calle the function to upload the image to the IPFS network
            collectible_metadata["image"] = image_to_upload             #the field image of our .json file is gonna contain the URI to the image
            with open(metadata_file_name, "w") as file:                 #here i'm gonna put in the json file the corresponging final metadata.
                json.dump(collectible_metadata,file)                    
            if os.getenv("UPLOAD_IPFS") == "true":                      #if the enviromental variable UPLOAD_IPFS is set to true, i'm gonna
                upload_to_ipfs(metadata_file_name)                      #upload to the IPFS also the .json file of the NFT i'm considering.

#http://127.0.0.1:5001                                                  #it is the localhost address for our IPFS
def upload_to_ipfs(filepath):                                           #i use the Path library to open the path passed in the function arguments
    with Path(filepath).open("rb") as fp:                               #i store the read value in the variable image_binary
        image_binary = fp.read()                                        #the ipfs url always starts with the local host address
        ipfs_url = "http://127.0.0.1:5001"                              #the response variable stores the requests with some changes. the URI
        response = requests.post(                                       #starts with the local host address, then it's added the path /api/v0/add
            ipfs_url +                                                  #that it's from the ipfs API. i add to the dictionary files the couple
            "/api/v0/add",                                              #"file": image_binary.
            files={"file": image_binary}                                
            )                                                           #the hash of our previous response is in the json file under the field
        ipfs_hash = response.json()["Hash"]                             #hash. this hash is the unique hash behind our NFT.
        filename = filepath.split("/")[-1:][0]                          #i remove from the file name everything that comes before the /.
        uri = "https://ipfs.io/ipfs/{}?filename{}".format(ipfs_hash, filename)#i create the URI by combining the base URL of ipfs and the 
        print(uri)                                                      #two variables created before.
        return uri                                                      #i print the uri that has been created.
    return None                                                         #i return the value of the URI if i can open the filepath. otherwise none

STATIC_SEED = 123                                                       #this is the seed i'll use for the randomness of our transactions

def step1():                                                            #this function will take care of the initial deploy of our smart contract
    dev = accounts.add(config['wallets']['from_key'])                   #i take from the accounts the wallet connected to my private key
    print(network.show_active())                                        #i show which network on which i'm working.
    publish_source = False                                              #i set the publish_source variable at false
    advanced_collectible = AdvancedCollectible.deploy(config['networks'][network.show_active()]['vrf_coordinator'],config['networks'][network.show_active()]['link_token'],config['networks'][network.show_active()]['keyhash'],{"from": dev},publish_source=publish_source)  
                                                                        #the contract i deploy on the network defined by the 3 values vrf_coordinator      
                                                                        #link_token and key hash, from the wallet declared earlier, is gonna be                                                 
                                                                        #stored in the variable advanced_collectible. i set the value of      
                                                                        #publish_source to the same value returned from the contract.
    fund_advanced_collectible(advanced_collectible)                     #i fund the advanced_collectible variable.
    return(advanced_collectible,dev)                                    #i return the contract i deploye and the account i used.

def main():                                                             
    advanced_collectible,dev = step1()                                  # i define advanced_collectible and dev as the contract and the wallet
    transaction = advanced_collectible.createCollectible(               # returned by the function step1.
        STATIC_SEED,                                                    # i create a transaction by calling the method of the deployed contract
        "None",                                                         # createCollectible, which accepts a seed for randomness, a string for 
        {"from":dev}                                                    #the tokenURI, which we'll create later.
        )                                                               # i add a third parameter which points the wallet we are using to deploy
    transaction.wait(1)                                                 #the transaction is gonna wait for another transaction to be done before
                                                                        # starting the next step.
    requestId = transaction.events['requestedCollectible']['requestId'] #request id stores the variable requestId from the event 
                                                                        #requestedCollectible in our smart contract.
    token_id = advanced_collectible.requestIdToTokenId(requestId)       #the variable token_id calles the requestIdTokenId with the requestId
                                                                        #we stored before.
    time.sleep(60)                                                      #i wait 60 seconds, so that i'm sure the transaction has been finalyzed
    breed = get_breed(advanced_collectible.tokenIdToBreed(token_id))    #the name of the NFT is given by the function defined earlier, where the
                                                                        #parameter is the result of the smart contract method tokenIdToBreed 
                                                                        #corresponding to the given token_id.
    print('Dog breed of token{} is {}'.format(token_id,breed))          #i print the token generated and the name of the NFT i created                                                                    
    number_of_tokens = advanced_collectible.tokenCounter()              #i define the number of tokens as the tokenCounter() value.
    print(f"you generated {number_of_tokens} tokens")                   #i print the number of tokens that have been generated.
    write_metadata(number_of_tokens, advanced_collectible)              #i call the write_metadata function, and end the execution.
  
if __name__ == "__main__":
    main()
