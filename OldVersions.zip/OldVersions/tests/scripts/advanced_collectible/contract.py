from brownie import *

def get_breed(breed_number):
    switch = {0: 'PUG', 1:'SHIBA_INU', 2:'ST_BERNARD', 3:'KAKKA',4:'NUNZIA'}
    return switch[breed_number]

STATIC_SEED = 123

def main():                                                             
    dev = accounts.add(config['wallets']['from_key'])                   #i take from the accounts the wallet connected to my private key
    print(network.show_active())                                        #i show which network on which i'm working.
    publish_source = False                                              #i set the publish_source variable at false
    advanced_collectible = Prova.deploy(config['networks'][network.show_active()]['vrf_coordinator'],config['networks'][network.show_active()]['link_token'],config['networks'][network.show_active()]['keyhash'],{"from": dev},publish_source=publish_source)  
    advanced_collectible = Prova[len(Prova) - 1]
    transaction = advanced_collectible.createToken(STATIC_SEED,"None",{"from":dev})
    transaction.wait(1)
    requestId = transaction.events['requestedCollectible']['requestId']
    token_id = advanced_collectible.requestIdToTokenId(requestId)
    time.sleep(60)dd
    
  
if __name__ == "__main__":
    main()
