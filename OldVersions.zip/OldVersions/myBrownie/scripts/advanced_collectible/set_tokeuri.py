from brownie import *

OPENSEA_FORMAT = "https://testnets.opensea.io/assets/{}/{}"

def main():
    print("Working on " + network.show_active())
    advanced_collectible = AdvancedCollectible[len(AdvancedCollectible) - 1]
    number_of_advanced_collectible = advanced_collectible.tokenCounter()
    print("The number of tokens you have deployed is : " + str(number_of_advanced_collectible))
    for token_id in range(number_of_advanced_collectible):
        breed = get_breed(advanced_collectible.tokenIdToBreed(tokenId))
        if not advanced_collectible.tokenURI(tokenId).startswith("https://"):
            print("setting token URI of {}".format(tokenId))
            set_tokenURI(tokenId, advanced_collectible, urls dictionaries)
        else:
            print("Skipping {}, we have already set that tokenURI!".format(token_id))

def set_tokenURI(token_id, nft_contract, tokenURI):
    dev = accounts.add(config['wallets']['from_key'])
    nft_contract.setTokenURI(token_id, tokenURI, {"from":dev})
    print("you can see your nft on {}".format(OPENSEAFORMAT.format(nft_contract.address, token_id)))
    print("Please give up to 20 minutes, and hit the refresh metadata button")
